# Origin of PRX-added test fixtures

These files exist alongside the upstream `bwavfile` test media (extracted from
`tests/test_media.tgz` via `create_test_media.sh`) and exercise the PRX-specific
features added on top of that fork: MP2/MPEG audio in the `data` chunk, the
`mext` chunk, and the AES46 `cart` chunk.

## MP2 audio fixtures (created by PRX)

These were generated from a sample of a radio news story clip:

- `test.mp2` — baseline MP2 frame, no ID3 tag.
- `test-id3.mp2` — same audio prefixed with an ID3v2 header (exercises the
  ID3-skip path in MPEG header parsing).
- `test-bad.mp2` — intentionally malformed MP2 for error-handling tests.

## Cart chunk fixtures (third-party)

- `cc_0101.wav` — public reference Cart Chunk sample from
  <http://www.cartchunk.org/samples.htm>.
- `60315.wav` — real-world broadcast WAV with cart chunk.
