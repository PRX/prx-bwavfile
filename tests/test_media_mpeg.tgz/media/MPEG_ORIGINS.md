# Origin of MPEG test fixtures

These files are added by `test_media_mpeg.tgz` to support tests for
the MPEG audio handling (`MpegInfo`, `BroadcastMpegFile`) added by
PRX's MPEG-in-BWF work.

## MP2 audio fixtures (created by PRX)

Generated from a sample of a radio news story clip:

- `test.mp2` — baseline MP2 frame, no ID3 tag.
- `test-id3.mp2` — same audio prefixed with an ID3v2 header
  (exercises the ID3-skip path in MPEG header parsing).
- `test-bad.mp2` — intentionally malformed MP2 for error-handling
  tests.
